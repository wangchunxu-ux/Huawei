import request from './request'

export const productAPI = {
  // 获取商品列表
  getProducts: (params = {}) => {
    return request.get('/products', { params })
  },
  
  // 获取商品详情
  getProductById: (id) => {
    return request.get(`/products/${id}`)
  },
  
  // 按分类获取商品
  getProductsByCategory: (category, params = {}) => {
    return request.get('/products', {
      params: { category, ...params }
    })
  },
  
  // 搜索商品
  searchProducts: (keyword, params = {}) => {
    return request.get('/products', {
      params: { q: keyword, ...params }
    })
  },
  
  // 获取分类列表
  getCategories: () => {
    return request.get('/categories')
  },
  
  // 获取轮播图
  getBanners: () => {
    return request.get('/banners')
  }
}