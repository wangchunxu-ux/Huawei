<template>
  <div class="product-detail" v-if="product">
    <div class="container">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item :to="{ path: `/products/${product.category}` }">
          {{ categoryName }}
        </el-breadcrumb-item>
        <el-breadcrumb-item>{{ product.name }}</el-breadcrumb-item>
      </el-breadcrumb>
      
      <div class="detail-content">
        <div class="product-gallery">
          <div class="main-image">
            <img :src="currentImage" :alt="product.name" />
          </div>
          <div class="image-list">
            <div
              v-for="(image, index) in product.images"
              :key="index"
              class="image-item"
              :class="{ active: currentImage === image }"
              @click="currentImage = image"
            >
              <img :src="image" :alt="`${product.name} ${index + 1}`" />
            </div>
          </div>
        </div>
        
        <div class="product-info">
          <h1 class="product-name">{{ product.name }}</h1>
          <p class="product-desc">{{ product.description }}</p>
          
          <div class="price-section">
            <div class="price-wrapper">
              <span class="label">价格</span>
              <span class="price">¥{{ product.price }}</span>
              <span class="original-price" v-if="product.originalPrice">
                ¥{{ product.originalPrice }}
              </span>
            </div>
            <div class="promotion" v-if="product.originalPrice">
              <el-tag type="danger">立省 ¥{{ product.originalPrice - product.price }}</el-tag>
            </div>
          </div>
          
          <div class="meta-section">
            <div class="meta-item">
              <span class="label">评分</span>
              <el-rate v-model="product.rating" disabled show-score />
            </div>
            <div class="meta-item">
              <span class="label">销量</span>
              <span>{{ product.sales }} 件</span>
            </div>
            <div class="meta-item">
              <span class="label">库存</span>
              <span>{{ product.stock }} 件</span>
            </div>
          </div>
          
          <div class="quantity-section">
            <span class="label">数量</span>
            <el-input-number
              v-model="quantity"
              :min="1"
              :max="product.stock"
              size="large"
            />
          </div>
          
          <div class="action-section">
            <el-button type="primary" size="large" @click="addToCart">
              加入购物车
            </el-button>
            <el-button type="danger" size="large" @click="buyNow">
              立即购买
            </el-button>
          </div>
        </div>
      </div>
      
      <ProductSpec :specs="product.specs">
        <template #title>技术规格</template>
      </ProductSpec>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import axios from 'axios'
import { ElMessage } from 'element-plus'
import ProductSpec from '../components/ProductSpec.vue'

const props = defineProps({
  id: String
})

const route = useRoute()
const router = useRouter()
const product = ref(null)
const categories = ref([])
const currentImage = ref('')
const quantity = ref(1)

const categoryName = computed(() => {
  if (!product.value) return ''
  const cat = categories.value.find(c => c.id === product.value.category)
  return cat ? cat.name : ''
})

onMounted(async () => {
  try {
    const [productRes, categoriesRes] = await Promise.all([
      axios.get(`http://localhost:3000/products/${props.id}`),
      axios.get('http://localhost:3000/categories')
    ])
    product.value = productRes.data
    categories.value = categoriesRes.data
    currentImage.value = product.value.images[0]
  } catch (error) {
    console.error('获取产品详情失败:', error)
    ElMessage.error('获取产品信息失败')
  }
})

const addToCart = () => {
  // 实际项目中应该调用API
  ElMessage.success(`已添加 ${quantity.value} 件商品到购物车`)
}

const buyNow = () => {
  // 实际项目中应该跳转到结算页面
  addToCart()
  router.push('/cart')
}
</script>

<style scoped>
.product-detail {
  padding: 20px 0 40px;
}

.el-breadcrumb {
  margin-bottom: 20px;
}

.detail-content {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 40px;
  background: #fff;
  padding: 30px;
  border-radius: 8px;
}

.product-gallery {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.main-image {
  width: 100%;
  height: 400px;
  background: #f8f8f8;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 8px;
  overflow: hidden;
}

.main-image img {
  max-width: 100%;
  max-height: 100%;
  object-fit: contain;
}

.image-list {
  display: flex;
  gap: 10px;
}

.image-item {
  width: 80px;
  height: 80px;
  border: 2px solid #eee;
  border-radius: 4px;
  overflow: hidden;
  cursor: pointer;
  transition: border-color 0.3s;
}

.image-item.active,
.image-item:hover {
  border-color: #ff6700;
}

.image-item img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.product-info {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.product-name {
  font-size: 28px;
  font-weight: 500;
  margin: 0;
}

.product-desc {
  color: #666;
  font-size: 16px;
}

.price-section {
  padding: 20px;
  background: #f8f8f8;
  border-radius: 8px;
}

.price-wrapper {
  display: flex;
  align-items: baseline;
  gap: 10px;
  margin-bottom: 10px;
}

.price {
  font-size: 32px;
  color: #ff6700;
  font-weight: bold;
}

.label {
  color: #666;
  margin-right: 10px;
}

.meta-section {
  display: flex;
  gap: 30px;
}

.meta-item {
  display: flex;
  align-items: center;
  gap: 10px;
}

.quantity-section {
  display: flex;
  align-items: center;
  gap: 20px;
}

.action-section {
  display: flex;
  gap: 20px;
}

.action-section .el-button {
  flex: 1;
  height: 48px;
  font-size: 16px;
}
</style>