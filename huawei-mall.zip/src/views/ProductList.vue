<template>
  <div class="product-list">
    <div class="container">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item :to="{ path: '/' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>{{ categoryName }}</el-breadcrumb-item>
      </el-breadcrumb>
      
      <div class="list-content">
        <aside class="filter-sidebar">
          <ProductFilter @filter-change="handleFilterChange" />
        </aside>
        
        <main class="product-main">
          <div class="list-header">
            <h1>{{ categoryName }}</h1>
            <span class="product-count">共 {{ filteredProducts.length }} 件商品</span>
          </div>
          
          <div class="products-grid" v-if="filteredProducts.length">
            <ProductCard
              v-for="product in filteredProducts"
              :key="product.id"
              :product="product"
              @add-to-cart="handleAddToCart"
            />
          </div>
          
          <el-empty v-else description="暂无商品" />
        </main>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, watch } from 'vue'
import { useRoute } from 'vue-router'
import axios from 'axios'
import ProductCard from '../components/ProductCard.vue'
import ProductFilter from '../components/ProductFilter.vue'

const props = defineProps({
  category: String,
  searchQuery: String
})

const route = useRoute()
const products = ref([])
const categories = ref([])
const filters = ref({
  priceRange: 'all',
  sortBy: 'default'
})

const categoryName = computed(() => {
  if (props.category === 'search') {
    return `搜索结果: "${props.searchQuery || route.query.q}"`
  }
  const cat = categories.value.find(c => c.id === props.category)
  return cat ? cat.name : '全部商品'
})

const filteredProducts = computed(() => {
  let result = []
  
  if (props.category === 'search') {
    // 搜索模式
    const query = (props.searchQuery || route.query.q || '').toLowerCase()
    result = products.value.filter(p => 
      p.name.toLowerCase().includes(query) ||
      p.description.toLowerCase().includes(query) ||
      p.category.toLowerCase().includes(query)
    )
  } else {
    // 分类模式
    result = products.value.filter(p => p.category === props.category)
  }
  
  // 价格筛选
  if (filters.value.priceRange !== 'all') {
    const [min, max] = filters.value.priceRange.split('-').map(v => 
      v === '+' ? Infinity : parseInt(v)
    )
    result = result.filter(p => {
      if (max === Infinity) return p.price >= min
      return p.price >= min && p.price <= max
    })
  }
  
  // 排序
  switch (filters.value.sortBy) {
    case 'price-asc':
      result.sort((a, b) => a.price - b.price)
      break
    case 'price-desc':
      result.sort((a, b) => b.price - a.price)
      break
    case 'sales':
      result.sort((a, b) => b.sales - a.sales)
      break
    case 'rating':
      result.sort((a, b) => b.rating - a.rating)
      break
  }
  
  return result
})

const loadData = async () => {
  try {
    const [productsRes, categoriesRes] = await Promise.all([
      axios.get('http://localhost:3000/products'),
      axios.get('http://localhost:3000/categories')
    ])
    products.value = productsRes.data
    categories.value = categoriesRes.data
  } catch (error) {
    console.error('获取数据失败:', error)
  }
}

onMounted(() => {
  loadData()
})

watch(() => [props.category, route.query.q], () => {
  loadData()
})

const handleFilterChange = (newFilters) => {
  filters.value = newFilters
}

const handleAddToCart = (product) => {
  console.log('添加到购物车:', product)
}
</script>

<style scoped>
.product-list {
  padding: 20px 0 40px;
  min-height: calc(100vh - 152px);
}

.el-breadcrumb {
  margin-bottom: 20px;
}

.list-content {
  display: grid;
  grid-template-columns: 260px 1fr;
  gap: 20px;
}

.filter-sidebar {
  position: sticky;
  top: 80px;
  height: fit-content;
}

.list-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.list-header h1 {
  font-size: 24px;
  font-weight: 500;
}

.product-count {
  color: #666;
}

.products-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
  gap: 20px;
}
</style>