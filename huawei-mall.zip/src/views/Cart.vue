<template>
  <div class="cart-page">
    <div class="container">
      <h1 class="page-title">购物车</h1>
      
      <div class="cart-content" v-if="cartItems.length">
        <el-table :data="cartItems" style="width: 100%">
          <el-table-column type="selection" width="55" />
          <el-table-column label="商品" width="400">
            <template #default="scope">
              <div class="product-info">
                <img :src="scope.row.image" :alt="scope.row.name" />
                <div>
                  <h4>{{ scope.row.name }}</h4>
                  <p>{{ scope.row.description }}</p>
                </div>
              </div>
            </template>
          </el-table-column>
          <el-table-column prop="price" label="单价" width="120">
            <template #default="scope">
              ¥{{ scope.row.price }}
            </template>
          </el-table-column>
          <el-table-column label="数量" width="200">
            <template #default="scope">
              <el-input-number
                v-model="scope.row.quantity"
                :min="1"
                :max="scope.row.stock"
                @change="updateQuantity(scope.row)"
              />
            </template>
          </el-table-column>
          <el-table-column label="小计" width="120">
            <template #default="scope">
              ¥{{ scope.row.price * scope.row.quantity }}
            </template>
          </el-table-column>
          <el-table-column label="操作" width="100">
            <template #default="scope">
              <el-button type="danger" link @click="removeItem(scope.$index)">
                删除
              </el-button>
            </template>
          </el-table-column>
        </el-table>
        
        <div class="cart-summary">
          <div class="summary-content">
            <div class="summary-item">
              <span>商品总数：</span>
              <span>{{ totalQuantity }} 件</span>
            </div>
            <div class="summary-item total">
              <span>总计：</span>
              <span class="price">¥{{ totalPrice }}</span>
            </div>
          </div>
          <el-button type="primary" size="large" @click="checkout">
            结算
          </el-button>
        </div>
      </div>
      
      <el-empty v-else description="购物车是空的">
        <el-button type="primary" @click="$router.push('/')">
          去购物
        </el-button>
      </el-empty>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { ElMessage } from 'element-plus'

// 模拟购物车数据
const cartItems = ref([
  {
    id: 1,
    name: 'HUAWEI Mate 60 Pro',
    description: '搭载麒麟9000S处理器，卫星通信',
    price: 6999,
    image: '/images/products/mate60pro.jpg',
    quantity: 1,
    stock: 100
  },
  {
    id: 2,
    name: 'HUAWEI FreeBuds Pro 3',
    description: '星闪连接，智慧动态降噪3.0',
    price: 1499,
    image: '/images/products/freebuds-pro3.jpg',
    quantity: 2,
    stock: 300
  }
])

const totalQuantity = computed(() => {
  return cartItems.value.reduce((total, item) => total + item.quantity, 0)
})

const totalPrice = computed(() => {
  return cartItems.value.reduce((total, item) => total + item.price * item.quantity, 0)
})

const updateQuantity = (item) => {
  // 实际项目中应该调用API更新
  console.log('更新数量:', item)
}

const removeItem = (index) => {
  cartItems.value.splice(index, 1)
  ElMessage.success('已从购物车移除')
}

const checkout = () => {
  ElMessage.success('前往结算')
  // 实际项目中应该跳转到结算页面
}
</script>

<style scoped>
.cart-page {
  padding: 20px 0 40px;
  min-height: calc(100vh - 152px);
}

.page-title {
  font-size: 28px;
  font-weight: 500;
  margin-bottom: 30px;
}

.cart-content {
  background: #fff;
  padding: 20px;
  border-radius: 8px;
}

.product-info {
  display: flex;
  align-items: center;
  gap: 16px;
}

.product-info img {
  width: 80px;
  height: 80px;
  object-fit: cover;
  border-radius: 4px;
}

.product-info h4 {
  font-size: 16px;
  margin-bottom: 4px;
}

.product-info p {
  font-size: 14px;
  color: #666;
}

.cart-summary {
  margin-top: 20px;
  padding-top: 20px;
  border-top: 1px solid #eee;
  display: flex;
  justify-content: flex-end;
  align-items: center;
  gap: 40px;
}

.summary-content {
  display: flex;
  flex-direction: column;
  gap: 10px;
  text-align: right;
}

.summary-item {
  display: flex;
  gap: 20px;
  font-size: 14px;
}

.summary-item.total {
  font-size: 18px;
  font-weight: 500;
}

.summary-item .price {
  color: #ff6700;
  font-size: 24px;
  font-weight: bold;
}
</style>