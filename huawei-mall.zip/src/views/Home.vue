<template>
  <div class="home">
    <BannerCarousel :banners="banners" />
    
    <div class="container">
      <CategoryGrid :categories="categories" />
      
      <section class="hot-products">
        <h2 class="section-title">热销产品</h2>
        <div class="products-grid">
          <ProductCard
            v-for="product in hotProducts"
            :key="product.id"
            :product="product"
            @add-to-cart="handleAddToCart"
          />
        </div>
      </section>
      
      <section class="new-products">
        <h2 class="section-title">新品推荐</h2>
        <div class="products-grid">
          <ProductCard
            v-for="product in newProducts"
            :key="product.id"
            :product="product"
            @add-to-cart="handleAddToCart"
          />
        </div>
      </section>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import BannerCarousel from '@/components/BannerCarousel.vue'
import CategoryGrid from '@/components/CategoryGrid.vue'
import ProductCard from '@/components/ProductCard.vue'
import request from '@/api/request'

// 响应式数据
const banners = ref([])
const hotProducts = ref([])
const newProducts = ref([])
const categories = ref([])

// 获取轮播图数据
const getBanners = async () => {
  try {
    const response = await request.get('/banners')
    banners.value = response.data
  } catch (error) {
    console.error('获取轮播图失败:', error)
  }
}

// 获取热门商品
const getHotProducts = async () => {
  try {
    const response = await request.get('/products?_limit=8')
    hotProducts.value = response.data
  } catch (error) {
    console.error('获取热门商品失败:', error)
  }
}

// 获取新品推荐
const getNewProducts = async () => {
  try {
    const response = await request.get('/products?_sort=id&_order=desc&_limit=8')
    newProducts.value = response.data
  } catch (error) {
    console.error('获取新品推荐失败:', error)
  }
}

// 获取分类数据
const getCategories = async () => {
  try {
    const response = await request.get('/categories')
    categories.value = response.data
  } catch (error) {
    console.error('获取分类失败:', error)
  }
}

// 添加到购物车处理函数
const handleAddToCart = (product) => {
  console.log('添加到购物车:', product)
  // 这里可以添加实际的购物车逻辑
}

// 组件挂载时获取数据
onMounted(() => {
  getBanners()
  getHotProducts()
  getNewProducts()
  getCategories()
})
</script>

<style scoped>
.home {
  padding-bottom: 40px;
}

.section-title {
  font-size: 28px;
  font-weight: 500;
  text-align: center;
  margin: 40px 0 30px;
  color: #333;
}

.products-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 20px;
  margin-bottom: 40px;
}

.container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 0 20px;
}
</style>