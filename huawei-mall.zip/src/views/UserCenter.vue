<template>
  <div class="user-center">
    <div class="container">
      <div class="user-header">
        <div class="user-info">
          <el-avatar :size="80" :src="userInfo.avatar" />
          <div class="info-text">
            <h2>{{ userInfo.nickname }}</h2>
            <p>{{ userInfo.level }} | 积分：{{ userInfo.points }}</p>
          </div>
        </div>
        <div class="user-stats">
          <div class="stat-item">
            <span class="stat-value">{{ orderStats.pending }}</span>
            <span class="stat-label">待付款</span>
          </div>
          <div class="stat-item">
            <span class="stat-value">{{ orderStats.shipping }}</span>
            <span class="stat-label">待发货</span>
          </div>
          <div class="stat-item">
            <span class="stat-value">{{ orderStats.receiving }}</span>
            <span class="stat-label">待收货</span>
          </div>
          <div class="stat-item">
            <span class="stat-value">{{ orderStats.completed }}</span>
            <span class="stat-label">已完成</span>
          </div>
        </div>
      </div>

      <el-tabs v-model="activeTab" class="user-tabs">
        <el-tab-pane label="个人信息" name="profile">
          <el-form :model="userForm" label-width="100px" style="max-width: 600px">
            <el-form-item label="用户名">
              <el-input v-model="userForm.username" disabled />
            </el-form-item>
            <el-form-item label="昵称">
              <el-input v-model="userForm.nickname" />
            </el-form-item>
            <el-form-item label="手机号">
              <el-input v-model="userForm.phone" />
            </el-form-item>
            <el-form-item label="邮箱">
              <el-input v-model="userForm.email" />
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="saveProfile">保存修改</el-button>
            </el-form-item>
          </el-form>
        </el-tab-pane>

        <el-tab-pane label="我的订单" name="orders">
          <el-table :data="orders" style="width: 100%">
            <el-table-column prop="orderNo" label="订单号" width="180" />
            <el-table-column prop="productName" label="商品" />
            <el-table-column prop="amount" label="金额">
              <template #default="scope">
                ¥{{ scope.row.amount }}
              </template>
            </el-table-column>
            <el-table-column prop="status" label="状态">
              <template #default="scope">
                <el-tag :type="getOrderStatusType(scope.row.status)">
                  {{ scope.row.status }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="createTime" label="下单时间" width="180" />
            <el-table-column label="操作" width="120">
              <template #default="scope">
                <el-button type="primary" link size="small">查看详情</el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-tab-pane>

        <el-tab-pane label="收货地址" name="address">
          <div class="address-list">
            <div v-for="address in addresses" :key="address.id" class="address-item">
              <div class="address-content">
                <div class="address-header">
                  <span class="address-name">{{ address.name }}</span>
                  <span class="address-phone">{{ address.phone }}</span>
                  <el-tag v-if="address.isDefault" type="primary" size="small">默认</el-tag>
                </div>
                <p class="address-detail">
                  {{ address.province }}{{ address.city }}{{ address.district }}{{ address.detail }}
                </p>
              </div>
              <div class="address-actions">
                <el-button link type="primary" size="small">编辑</el-button>
                <el-button link type="danger" size="small">删除</el-button>
              </div>
            </div>
            <el-button type="primary" icon="Plus">添加新地址</el-button>
          </div>
        </el-tab-pane>

        <el-tab-pane label="账户安全" name="security">
          <div class="security-section">
            <div class="security-item">
              <div class="security-info">
                <h4>登录密码</h4>
                <p>定期更改密码可以提高账户安全性</p>
              </div>
              <el-button>修改密码</el-button>
            </div>
            <div class="security-item">
              <div class="security-info">
                <h4>手机绑定</h4>
                <p>已绑定手机：{{ userInfo.phone }}</p>
              </div>
              <el-button>更换手机</el-button>
            </div>
            <div class="security-item">
              <div class="security-info">
                <h4>邮箱绑定</h4>
                <p>已绑定邮箱：{{ userInfo.email }}</p>
              </div>
              <el-button>修改邮箱</el-button>
            </div>
          </div>
        </el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { ElMessage } from 'element-plus'

const activeTab = ref('profile')

const userInfo = ref({
  username: 'user001',
  nickname: '华为用户',
  avatar: '/images/avatars/user1.jpg',
  phone: '138****1234',
  email: 'user@example.com',
  points: 2580,
  level: '金牌会员'
})

const userForm = ref({
  username: 'user001',
  nickname: '华为用户',
  phone: '13812341234',
  email: 'user@example.com'
})

const orderStats = ref({
  pending: 2,
  shipping: 1,
  receiving: 3,
  completed: 15
})

const orders = ref([
  {
    orderNo: '202401250001',
    productName: 'HUAWEI Mate 60 Pro',
    amount: 6999,
    status: '已完成',
    createTime: '2024-01-25 10:30:00'
  },
  {
    orderNo: '202401240002',
    productName: 'HUAWEI FreeBuds Pro 3',
    amount: 1499,
    status: '待发货',
    createTime: '2024-01-24 15:20:00'
  },
  {
    orderNo: '202401230003',
    productName: 'HUAWEI WATCH Ultimate',
    amount: 7999,
    status: '待收货',
    createTime: '2024-01-23 09:15:00'
  }
])

const addresses = ref([
  {
    id: 1,
    name: '张三',
    phone: '13812341234',
    province: '广东省',
    city: '深圳市',
    district: '南山区',
    detail: '科技园南路XX号XX大厦XX层',
    isDefault: true
  },
  {
    id: 2,
    name: '李四',
    phone: '13856785678',
    province: '北京市',
    city: '北京市',
    district: '海淀区',
    detail: '中关村大街XX号',
    isDefault: false
  }
])

const getOrderStatusType = (status) => {
  const typeMap = {
    '待付款': 'warning',
    '待发货': 'primary',
    '待收货': 'info',
    '已完成': 'success',
    '已取消': 'danger'
  }
  return typeMap[status] || 'info'
}

const saveProfile = () => {
  ElMessage.success('个人信息已保存')
}
</script>

<style scoped>
.user-center {
  padding: 20px 0 40px;
  min-height: calc(100vh - 152px);
}

.user-header {
  background: #fff;
  padding: 30px;
  border-radius: 8px;
  margin-bottom: 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.user-info {
  display: flex;
  align-items: center;
  gap: 20px;
}

.info-text h2 {
  font-size: 24px;
  margin-bottom: 8px;
}

.info-text p {
  color: #666;
}

.user-stats {
  display: flex;
  gap: 40px;
}

.stat-item {
  text-align: center;
}

.stat-value {
  display: block;
  font-size: 24px;
  font-weight: bold;
  color: #ff6700;
  margin-bottom: 4px;
}

.stat-label {
  color: #666;
  font-size: 14px;
}

.user-tabs {
  background: #fff;
  padding: 20px;
  border-radius: 8px;
}

/* 地址相关样式 */
.address-list {
  max-width: 800px;
}

.address-item {
  border: 1px solid #eee;
  border-radius: 8px;
  padding: 16px;
  margin-bottom: 16px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.address-header {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 8px;
}

.address-name {
  font-weight: bold;
}

.address-phone {
  color: #666;
}

.address-detail {
  color: #666;
  margin: 0;
}

/* 安全设置样式 */
.security-section {
  max-width: 600px;
}

.security-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px 0;
  border-bottom: 1px solid #eee;
}

.security-item:last-child {
  border-bottom: none;
}

.security-info h4 {
  margin-bottom: 8px;
}

.security-info p {
  color: #666;
  margin: 0;
}
</style>