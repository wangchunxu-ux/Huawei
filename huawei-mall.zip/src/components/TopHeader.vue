<template>
  <div class="top-header">
    <div class="container">
      <div class="header-content">
        <div class="left">
          <span>华为官网</span>
          <el-divider direction="vertical" />
          <span>荣耀官网</span>
          <el-divider direction="vertical" />
          <span>企业购</span>
        </div>
        <div class="right">
          <router-link to="/user" class="user-link">
            <el-icon><User /></el-icon>
            <span>个人中心</span>
          </router-link>
          <el-divider direction="vertical" />
          <router-link to="/cart" class="cart-link">
            <el-badge :value="cartCount" :max="99" class="cart-badge">
              <el-icon><ShoppingCart /></el-icon>
              <span>购物车</span>
            </el-badge>
          </router-link>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { User, ShoppingCart } from '@element-plus/icons-vue'

// 模拟购物车数量
const cartCount = ref(3)
</script>

<style scoped>
.top-header {
  background-color: #111;
  color: #999;
  font-size: 12px;
  height: 32px;
  line-height: 32px;
}

.header-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.left, .right {
  display: flex;
  align-items: center;
  gap: 10px;
}

.user-link, .cart-link {
  color: #999;
  display: flex;
  align-items: center;
  gap: 4px;
  transition: color 0.3s;
}

.user-link:hover, .cart-link:hover {
  color: #fff;
}

.el-divider--vertical {
  height: 12px;
  margin: 0 10px;
  background-color: #333;
}

.cart-badge {
  line-height: 32px;
}
</style>