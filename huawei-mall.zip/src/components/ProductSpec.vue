<template>
  <div class="product-spec">
    <h3 class="spec-title">
      <slot name="title">产品参数</slot>
    </h3>
    <el-table :data="specData" style="width: 100%">
      <el-table-column prop="name" label="参数名" width="180" />
      <el-table-column prop="value" label="参数值" />
    </el-table>
  </div>
</template>

<script setup>
import { computed } from 'vue'

const props = defineProps({
  specs: {
    type: Object,
    default: () => ({})
  }
})

const specData = computed(() => {
  return Object.entries(props.specs).map(([name, value]) => ({
    name,
    value
  }))
})
</script>

<style scoped>
.product-spec {
  background: #fff;
  padding: 20px;
  border-radius: 8px;
  margin-top: 20px;
}

.spec-title {
  font-size: 20px;
  font-weight: 500;
  margin-bottom: 20px;
}
</style>