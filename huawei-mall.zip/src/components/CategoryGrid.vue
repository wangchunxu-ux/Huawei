<template>
  <div class="category-grid">
    <h2 class="section-title">
      <slot name="title">产品分类</slot>
    </h2>
    <div class="categories">
      <div
        v-for="category in categories"
        :key="category.id"
        class="category-item"
        @click="goToCategory(category.id)"
      >
        <div class="category-image">
          <img :src="category.image" :alt="category.name" />
        </div>
        <div class="category-info">
          <el-icon :size="32">
            <component :is="getIcon(category.icon)" />
          </el-icon>
          <h3>{{ category.name }}</h3>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router'
import { Cellphone, Monitor, Watch, Headset } from '@element-plus/icons-vue'

const props = defineProps({
  categories: {
    type: Array,
    default: () => []
  }
})

const router = useRouter()

const iconMap = {
  Cellphone,
  Monitor,
  Watch,
  Headset
}

const getIcon = (iconName) => {
  return iconMap[iconName] || Monitor
}

const goToCategory = (categoryId) => {
  router.push(`/products/${categoryId}`)
}
</script>

<style scoped>
.category-grid {
  margin-bottom: 40px;
}

.section-title {
  font-size: 28px;
  font-weight: 500;
  text-align: center;
  margin-bottom: 30px;
}

.categories {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 20px;
}

.category-item {
  background: #fff;
  border-radius: 8px;
  overflow: hidden;
  cursor: pointer;
  transition: all 0.3s;
  text-align: center;
}

.category-item:hover {
  transform: translateY(-4px);
  box-shadow: 0 8px 16px rgba(0,0,0,0.1);
}

.category-image {
  height: 150px;
  overflow: hidden;
  background: #f8f8f8;
}

.category-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.category-info {
  padding: 20px;
}

.category-info h3 {
  margin-top: 10px;
  font-size: 18px;
  font-weight: 500;
}
</style>