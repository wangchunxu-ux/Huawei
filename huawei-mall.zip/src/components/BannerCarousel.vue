<template>
  <div class="banner-carousel">
    <el-carousel :interval="5000" height="400px">
      <el-carousel-item v-for="banner in banners" :key="banner.id">
        <router-link :to="banner.link" class="banner-link">
          <div class="banner-image" :style="{ backgroundImage: `url(${banner.image})` }">
            <div class="banner-content">
              <h2 class="banner-title">{{ banner.title }}</h2>
              <p class="banner-subtitle">{{ banner.subtitle }}</p>
              <el-button type="primary" size="large">立即查看</el-button>
            </div>
          </div>
        </router-link>
      </el-carousel-item>
    </el-carousel>
  </div>
</template>

<script setup>
defineProps({
  banners: {
    type: Array,
    default: () => []
  }
})
</script>

<style scoped>
.banner-carousel {
  margin-bottom: 40px;
}

.banner-link {
  display: block;
  height: 100%;
}

.banner-image {
  height: 400px;
  background-size: cover;
  background-position: center;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
}

.banner-image::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0,0,0,0.3);
}

.banner-content {
  position: relative;
  text-align: center;
  color: #fff;
  z-index: 1;
}

.banner-title {
  font-size: 48px;
  font-weight: bold;
  margin-bottom: 16px;
}

.banner-subtitle {
  font-size: 24px;
  margin-bottom: 24px;
}
</style>