<template>
  <div class="product-filter">
    <div class="filter-section">
      <h4>价格区间</h4>
      <el-radio-group v-model="priceRange" @change="handleFilterChange">
        <el-radio label="all">全部</el-radio>
        <el-radio label="0-2000">2000元以下</el-radio>
        <el-radio label="2000-5000">2000-5000元</el-radio>
        <el-radio label="5000-10000">5000-10000元</el-radio>
        <el-radio label="10000+">10000元以上</el-radio>
      </el-radio-group>
    </div>
    
    <div class="filter-section">
      <h4>排序方式</h4>
      <el-radio-group v-model="sortBy" @change="handleFilterChange">
        <el-radio label="default">默认排序</el-radio>
        <el-radio label="price-asc">价格从低到高</el-radio>
        <el-radio label="price-desc">价格从高到低</el-radio>
        <el-radio label="sales">销量优先</el-radio>
        <el-radio label="rating">评分优先</el-radio>
      </el-radio-group>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'

const emit = defineEmits(['filter-change'])

const priceRange = ref('all')
const sortBy = ref('default')

const handleFilterChange = () => {
  emit('filter-change', {
    priceRange: priceRange.value,
    sortBy: sortBy.value
  })
}
</script>

<style scoped>
.product-filter {
  background: #fff;
  padding: 20px;
  border-radius: 8px;
  margin-bottom: 20px;
}

.filter-section {
  margin-bottom: 20px;
}

.filter-section:last-child {
  margin-bottom: 0;
}

.filter-section h4 {
  margin-bottom: 10px;
  font-size: 16px;
  font-weight: 500;
}

.el-radio-group {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.el-radio {
  margin-right: 0;
}
</style>