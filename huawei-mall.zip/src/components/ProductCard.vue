<template>
  <div class="product-card" @click="goToDetail">
    <div class="product-image">
      <img :src="product.image" :alt="product.name" />
      <div class="product-badge" v-if="product.originalPrice">
        <span>直降{{ product.originalPrice - product.price }}元</span>
      </div>
    </div>
    <div class="product-info">
      <h3 class="product-name">{{ product.name }}</h3>
      <p class="product-desc">{{ product.description }}</p>
      <div class="product-meta">
        <div class="price-wrapper">
          <span class="price">¥{{ product.price }}</span>
          <span class="original-price" v-if="product.originalPrice">
            ¥{{ product.originalPrice }}
          </span>
        </div>
        <div class="product-stats">
          <el-rate v-model="product.rating" disabled show-score />
          <span class="sales">已售 {{ product.sales }}</span>
        </div>
      </div>
      <div class="product-actions">
        <el-button type="primary" size="small" @click.stop="addToCart">
          加入购物车
        </el-button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'

const props = defineProps({
  product: {
    type: Object,
    required: true
  }
})

const emit = defineEmits(['add-to-cart'])

const router = useRouter()

const goToDetail = () => {
  router.push(`/product/${props.product.id}`)
}

const addToCart = () => {
  emit('add-to-cart', props.product)
  ElMessage.success('已添加到购物车')
}
</script>

<style scoped>
.product-card {
  background: #fff;
  border-radius: 8px;
  overflow: hidden;
  cursor: pointer;
  transition: all 0.3s;
  box-shadow: 0 2px 8px rgba(0,0,0,0.06);
}

.product-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 8px 16px rgba(0,0,0,0.1);
}

.product-image {
  position: relative;
  width: 100%;
  height: 240px;
  overflow: hidden;
  background: #f8f8f8;
}

.product-image img {
  width: 100%;
  height: 100%;
  object-fit: contain;
  transition: transform 0.3s;
}

.product-card:hover .product-image img {
  transform: scale(1.05);
}

.product-badge {
  position: absolute;
  top: 10px;
  right: 10px;
  background: #ff6700;
  color: #fff;
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 12px;
}

.product-info {
  padding: 16px;
}

.product-name {
  font-size: 16px;
  font-weight: 500;
  margin-bottom: 8px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.product-desc {
  color: #666;
  font-size: 14px;
  margin-bottom: 12px;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  
  -webkit-box-orient: vertical;
}

.product-meta {
  margin-bottom: 12px;
}

.price-wrapper {
  margin-bottom: 8px;
}

.product-stats {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 12px;
  color: #999;
}

.sales {
  margin-left: auto;
}

.product-actions {
  display: flex;
  justify-content: center;
}
</style>