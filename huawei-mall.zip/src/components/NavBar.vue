<template>
  <nav class="navbar">
    <div class="container">
      <div class="nav-content">
        <router-link to="/" class="logo">
          <img src="/images/logo_app.png" alt="HUAWEI" loading="lazy" />
        </router-link>
        
        <el-menu
          mode="horizontal"
          :default-active="activeIndex"
          class="nav-menu"
          @select="handleSelect"
        >
          <el-menu-item index="/">首页</el-menu-item>
          <el-menu-item 
            v-for="category in categories" 
            :key="category.id"
            :index="`/products/${category.slug}`"
          >
            {{ category.name }}
          </el-menu-item>
        </el-menu>
        
        <div class="nav-actions">
          <div class="search-box">
            <el-input
              v-model="searchText"
              placeholder="搜索商品"
              prefix-icon="Search"
              @keyup.enter="handleSearch"
              clearable
            />
          </div>
          
          <div class="cart-icon" @click="goToCart">
            <el-icon size="24"><ShoppingCart /></el-icon>
          </div>
        </div>
      </div>
    </div>
  </nav>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { useCartStore } from '@/stores/index'
import axios from 'axios'

const router = useRouter()
const route = useRoute()
const cartStore = useCartStore()
const searchText = ref('')
const categories = ref([])

const activeIndex = computed(() => route.path)

const handleSelect = (index) => {
  router.push(index)
}

const handleSearch = async () => {
  if (searchText.value.trim()) {
    try {
      // 搜索商品
      const response = await axios.get(`http://localhost:3000/products?q=${searchText.value.trim()}`)
      const searchResults = response.data
      
      // 如果只有一个结果，直接跳转到商品详情页
      if (searchResults.length === 1) {
        router.push(`/product/${searchResults[0].id}`)
      } else {
        // 多个结果或无结果，跳转到搜索结果页
        router.push({
          path: '/search',
          query: { q: searchText.value }
        })
      }
      
      // 清空搜索框
      searchText.value = ''
    } catch (error) {
      console.error('搜索失败:', error)
      // 搜索失败时仍然跳转到搜索页面
      router.push({
        path: '/search',
        query: { q: searchText.value }
      })
    }
  }
}

const goToCart = () => {
  router.push('/cart')
}

const loadCategories = async () => {
  try {
    const response = await axios.get('http://localhost:3000/categories')
    categories.value = response.data
  } catch (error) {
    console.error('获取分类失败:', error)
  }
}

onMounted(() => {
  loadCategories()
})
</script>

<style scoped>
.navbar {
  background: #fff;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  position: sticky;
  top: 0;
  z-index: 1000;
}

.nav-content {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 64px;
}

.logo img {
  height: 40px;
  width: auto;
}

.nav-menu {
  flex: 1;
  margin: 0 40px;
  border-bottom: none;
}

.nav-actions {
  display: flex;
  align-items: center;
  gap: 20px;
}

.search-box {
  width: 300px;
}

.cart-icon {
  cursor: pointer;
  padding: 8px;
  border-radius: 4px;
  transition: background-color 0.3s;
}

.cart-icon:hover {
  background-color: #f5f5f5;
}
</style>