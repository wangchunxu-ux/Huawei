<template>
  <footer class="footer">
    <div class="container">
      <div class="footer-content">
        <div class="footer-section">
          <h4>购买支持</h4>
          <ul>
            <li><a href="#">购买指南</a></li>
            <li><a href="#">配送方式</a></li>
            <li><a href="#">支付方式</a></li>
            <li><a href="#">常见问题</a></li>
          </ul>
        </div>
        <div class="footer-section">
          <h4>服务支持</h4>
          <ul>
            <li><a href="#">保修政策</a></li>
            <li><a href="#">退换货政策</a></li>
            <li><a href="#">服务网点</a></li>
            <li><a href="#">预约维修</a></li>
          </ul>
        </div>
        <div class="footer-section">
          <h4>关于华为</h4>
          <ul>
            <li><a href="#">公司介绍</a></li>
            <li><a href="#">新闻中心</a></li>
            <li><a href="#">加入我们</a></li>
            <li><a href="#">联系我们</a></li>
          </ul>
        </div>
        <div class="footer-section">
          <h4>关注我们</h4>
          <div class="social-links">
            <el-icon :size="24"><ChatDotRound /></el-icon>
            <el-icon :size="24"><Share /></el-icon>
            <el-icon :size="24"><Phone /></el-icon>
          </div>
          <p class="hotline">客服热线：950800</p>
        </div>
      </div>
      <div class="footer-bottom">
        <p>&copy; 2024 华为技术有限公司 版权所有</p>
        <p>粤ICP备19015800号</p>
      </div>
    </div>
  </footer>
</template>

<script setup>
import { ChatDotRound, Share, Phone } from '@element-plus/icons-vue'
</script>

<style scoped>
.footer {
  background-color: #1a1a1a;
  color: #999;
  padding: 40px 0 20px;
  margin-top: auto;
}

.footer-content {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 40px;
  margin-bottom: 30px;
}

.footer-section h4 {
  color: #fff;
  font-size: 16px;
  margin-bottom: 20px;
}

.footer-section ul {
  list-style: none;
}

.footer-section li {
  margin-bottom: 12px;
}

.footer-section a {
  color: #999;
  transition: color 0.3s;
}

.footer-section a:hover {
  color: #fff;
}

.social-links {
  display: flex;
  gap: 16px;
  margin-bottom: 16px;
}

.social-links .el-icon {
  cursor: pointer;
  transition: color 0.3s;
}

.social-links .el-icon:hover {
  color: #fff;
}

.hotline {
  font-size: 18px;
  color: #ff6700;
  font-weight: bold;
}

.footer-bottom {
  text-align: center;
  padding-top: 20px;
  border-top: 1px solid #333;
}

.footer-bottom p {
  margin: 5px 0;
  font-size: 12px;
}
</style>